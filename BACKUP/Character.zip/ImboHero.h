#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
//#include "GenericTeamAgentInterface.h"
#include "Components/TimelineComponent.h"
#include "ImboHero.generated.h"


class USpringArmComponent;
class UCameraComponent;
class AImboBaseHeroController;


UCLASS()
class IMBOGAME_API AImboHero : public ACharacter
{
	GENERATED_BODY()


public:	
	/* Default */
	AImboHero();
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;


	/* Input */
	void OnMoveForward(float InAxis);
	void OnMoveRight(float InAxis);
	void OnTurn(float InAxis);
	void OnLookup(float InAxis);

	void OnClickMouseLeft();
	void OnUnClickMouseLeft();
	void OnClickMouseRight();
	void OnUnClickMouseRight();

	void OnStartJump();
	void OnEndJump();


public:
	/* Blueprint Getter */
	UFUNCTION(BlueprintCallable, Category="Imbo|Character")
		AImboBaseHeroController* GetImboPlayerController() const;

	UFUNCTION(BlueprintCallable, Category = "Imbo|Character")
		USpringArmComponent* GetImboPlayerSpringArmComponent() const;

	UFUNCTION(BlueprintCallable, Category = "Imbo|Character")
		UCameraComponent* GetImboPlayerCameraComponent() const;

 
	/* Default Component */
	UPROPERTY(EditAnywhere, /*BlueprintReadOnly,*/ Category = Camera, meta = (AllowPrivateAccess = "true"))
		USpringArmComponent* SpringArm;

	UPROPERTY(EditAnywhere, /*BlueprintReadOnly,*/ Category = Camera, meta = (AllowPrivateAccess = "true"))
		UCameraComponent* Camera;


private:
	/* Default Properties */
	bool bClickMouseLeft;
	bool bClickMouseRight;

	float DefaultMouseX;
	float DefaultMouseY;


private:
	/* Camera Zoom */
	float MinCameraZoom;
	float MaxCameraZoom;
	
	UPROPERTY(EditAnywhere)
		TObjectPtr<UCurveFloat> CameraZoomCurveFloat;

	UFUNCTION()
		void OnCameraZoomUpdate(float Output);

	FTimeline CameraZoomTimline;
	FOnTimelineFloat CameraZoomInterp;
};
