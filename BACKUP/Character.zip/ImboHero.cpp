#include "Character/ImboHero.h"
#include "Global.h"

#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Camera/CameraComponent.h"

#include "Controller/ImboBaseHeroController.h"
#include "Blueprint/WidgetBlueprintLibrary.h"

#include "GameplayTags.h"

AImboHero::AImboHero()
{
	/* Set Default Pawn */
	PrimaryActorTick.bCanEverTick = true;
	bUseControllerRotationPitch = false; //Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	
	/* Create Default Component */
	ImboHelpers::CreateComponent<USpringArmComponent>(this, &SpringArm, TEXT("SpringArm"), GetCapsuleComponent());
	ImboHelpers::CreateComponent<UCameraComponent>(this, &Camera, TEXT("Camera"), SpringArm);


	/* Create Actor Component */
	


	/* Set Mesh */
	//USkeletalMeshComponent* setMeshComp = GetMesh();
	//USkeletalMesh* mainMesh;
	//ImboHelpers::GetAsset<USkeletalMesh>(&mainMesh, TEXT("SkeletalMesh'/Game/Asset/Characters/Mannequins/Meshes/SKM_Manny.SKM_Manny'"));
	//setMeshComp->SetSkeletalMesh(mainMesh);
	//setMeshComp->SetRelativeLocation(FVector(0, 0, -90));
	//setMeshComp->SetRelativeRotation(FRotator(0, -90, 0));


	///* Set AnimInstance */
	//TSubclassOf<UAnimInstance> animInstance;
	//ImboHelpers::GetClass(&animInstance, TEXT("AnimBlueprint'/Game/Blueprint/Animation/Hero/AB_ImboHeroAnimInstance.AB_ImboHeroAnimInstance_C'"));
	//setMeshComp->SetAnimationMode(EAnimationMode::AnimationBlueprint);
	//setMeshComp->SetAnimClass(animInstance);


	/* Set SpringArm & Camera */
	SpringArm->bUsePawnControlRotation = true;
	SpringArm->TargetArmLength = 1500.f;
	SpringArm->bDoCollisionTest = true;
	SpringArm->bEnableCameraLag = true;
	Camera->bUsePawnControlRotation = false; //Camera does not rotate relative to arm


	/* Configure Character Movement */
	GetCharacterMovement()->bOrientRotationToMovement = true; //Rotate Character to Controller


	/* Set TeamID */
	//TODO : 


	/* Set Camera Zoom Timeline */
	MinCameraZoom = 300.0f;
	MaxCameraZoom = 1500.0f;
	CameraZoomInterp.BindUFunction(this, TEXT("OnCameraZoomUpdate"));
}

void AImboHero::BeginPlay()
{
	Super::BeginPlay();


	/* Test Use Tag */
	UGameplayTagsManager& tempManager = UGameplayTagsManager::Get();

	FGameplayTag tempTag = FGameplayTag::RequestGameplayTag(FName("Class.Commoner")); // Ok
	//FGameplayTag tempTag = tempManager.RequestGameplayTagChildren(FGameplayTag(FName("Character"))); // Fail, please get the container

	if (tempTag.IsValid())
	{
		ImboLog::Print("Success Get Tag!!");
		ImboLog::Print(tempTag.ToString());

	}

	/* Set Camera Zoom Timeline */
	CameraZoomTimline.SetFloatCurve(CameraZoomCurveFloat.Get(), TEXT("Percentage"));
	CameraZoomTimline.SetTimelineLength(1.0f);
	CameraZoomTimline.AddInterpFloat(CameraZoomCurveFloat.Get(), CameraZoomInterp, TEXT("CameraZoom"), TEXT("Percentage"));
}

void AImboHero::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	CameraZoomTimline.TickTimeline(DeltaTime);

}

void AImboHero::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	check(PlayerInputComponent);
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	

	/* Set Default Input */
	PlayerInputComponent->BindAxis("MoveForward", this, &AImboHero::OnMoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &AImboHero::OnMoveRight);
	PlayerInputComponent->BindAxis("Turn", this, &AImboHero::OnTurn);
	PlayerInputComponent->BindAxis("Lookup", this, &AImboHero::OnLookup);


	/* Set Mouse Key */
	PlayerInputComponent->BindAction("MouseLeft", EInputEvent::IE_Pressed, this, &AImboHero::OnClickMouseLeft);
	PlayerInputComponent->BindAction("MouseLeft", EInputEvent::IE_Released, this, &AImboHero::OnUnClickMouseLeft);
	PlayerInputComponent->BindAction("MouseRight", EInputEvent::IE_Pressed, this, &AImboHero::OnClickMouseRight);
	PlayerInputComponent->BindAction("MouseRight", EInputEvent::IE_Released, this, &AImboHero::OnUnClickMouseRight);


	/* Set Mouse Key */
	PlayerInputComponent->BindAction("Jump", EInputEvent::IE_Pressed, this, &AImboHero::OnStartJump);
	PlayerInputComponent->BindAction("Jump", EInputEvent::IE_Released, this, &AImboHero::OnEndJump);
}

void AImboHero::OnMoveForward(float InAxis)
{
	if (bClickMouseRight)
	{
		if ((Controller != nullptr) && (InAxis != 0.0f))
		{
			const FRotator rotation = Controller->GetControlRotation();
			const FRotator YawRotation(0, rotation.Yaw, 0);
			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);
			AddMovementInput(Direction, InAxis);
		}
	}
}

void AImboHero::OnMoveRight(float InAxis)
{
	if (bClickMouseRight)
	{
		if ((Controller != nullptr) && (InAxis != 0.0f))
		{
			const FRotator rotation = Controller->GetControlRotation();
			const FRotator YawRotation(0, rotation.Yaw, 0);
			const FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);
			AddMovementInput(Direction, InAxis);
		}
	}
}

void AImboHero::OnTurn(float InAxis)
{
	if (bClickMouseLeft || bClickMouseRight)
	{
		if (UKismetMathLibrary::NearlyEqual_FloatFloat(InAxis, 0.0f) == false)
		{
			APlayerController* tempController = Cast<APlayerController>(Controller);
			tempController->SetShowMouseCursor(false);
			AddControllerYawInput(InAxis);
		}
	}
}

void AImboHero::OnLookup(float InAxis)
{
	if (bClickMouseLeft || bClickMouseRight)
	{
		if (UKismetMathLibrary::NearlyEqual_FloatFloat(InAxis, 0.0f) == false)
		{
			APlayerController* tempController = Cast<APlayerController>(Controller);
			tempController->SetShowMouseCursor(false);
			AddControllerPitchInput(InAxis);
		}
	}
}

void AImboHero::OnClickMouseLeft()
{
	bClickMouseLeft = true;
	GetImboPlayerController()->GetMousePosition(DefaultMouseX, DefaultMouseY);
}

void AImboHero::OnUnClickMouseLeft()
{
	bClickMouseLeft = false;

	APlayerController* tempController = GetImboPlayerController();
	tempController->SetMouseLocation(DefaultMouseX, DefaultMouseY);
	tempController->SetShowMouseCursor(true);
	UWidgetBlueprintLibrary::SetInputMode_GameAndUIEx(GetImboPlayerController());
}

void AImboHero::OnClickMouseRight()
{
	bClickMouseRight = true;
	GetImboPlayerController()->GetMousePosition(DefaultMouseX, DefaultMouseY);
}

void AImboHero::OnUnClickMouseRight()
{
	bClickMouseRight = false;

	APlayerController* tempController = GetImboPlayerController();
	tempController->SetMouseLocation(DefaultMouseX, DefaultMouseY);
	tempController->SetShowMouseCursor(true);
	UWidgetBlueprintLibrary::SetInputMode_GameAndUIEx(GetImboPlayerController());
}

void AImboHero::OnStartJump()
{
	if(GetMovementComponent()->IsMovingOnGround() == true)
	{
		Jump();
	}
}

void AImboHero::OnEndJump()
{
	StopJumping();
}

AImboBaseHeroController* AImboHero::GetImboPlayerController() const
{
	return CastChecked<AImboBaseHeroController>(Controller, ECastCheckedType::NullAllowed);
}

USpringArmComponent* AImboHero::GetImboPlayerSpringArmComponent() const
{
	return SpringArm;
}

UCameraComponent* AImboHero::GetImboPlayerCameraComponent() const
{
	return Camera;
}

void AImboHero::OnCameraZoomUpdate(float Output)
{
	//FVector vTemp(SpringArm->GetRelativeLocation());
	//vTemp.Z = UKismetMathLibrary::Lerp(OriginalCameraHeight, NewCameraHeight, value);
	//
	//OwnerCharacter->SpringArm->SetRelativeLocation(vTemp);
	//CurrentCameraHeight = vTemp.Z;
}
